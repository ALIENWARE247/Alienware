function toggleMenu() {
  const links = document.getElementById('nav-links');
  links.classList.toggle('active');
}

// Optional: disable form submission for now
document.querySelector('form').addEventListener('submit', e => {
  e.preventDefault();
  alert("Message feature coming soon!");
});